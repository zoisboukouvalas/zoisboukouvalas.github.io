clc
clear 
close all
%% 
%MGGD sources Generation
%{
N=2; %Sources
K=2; %Number of datasets
T=10000;
S=zeros(N,T,K);

beta1=0.65;
alpha1=0.6;
mu1=5; %Mean of each of the marginals
paramGGD1=[alpha1 2*beta1 -mu1; 1-alpha1 2*beta1 mu1];
S(1,:,:) = genMixGGDmD( paramGGD1, 1, 1, K, T )';

beta2=0.70;
alpha2=0.6;
mu2=10; %Mean of each of the marginals
paramGGD2=[alpha2 2*beta2 -mu2; 1-alpha2 2*beta2 mu2];
S(2,:,:) = genMixGGDmD( paramGGD2, 1, 1, K, T )';

A = randn(N,N,K);

for k=1:K
    X(:,:,k)=A(:,:,k)*S(:,:,k);
end

for kk=1:K
    wnit(:,:,kk)= randn(N,N);
end
%}

%Simple MGGD sources experiment
files = importdata('MGGD_sources.mat');
A = files.A; 
S = files.S;
X = files.X;
wnit = files.wnit;

%% IVA-M-EMK
tic
[W,cost, jointisi_m_emk, avgisiMEMK, iterMoM] = iva_m_emk(X,'A', A,'initW',wnit);
toc

